<?php
	
	class Seguimiento extends AppModel
	{
		var $name='Seguimiento'; // nombre del modelo
		var $primaryKey='num_evento';
		var $belongsTo=array('Voluntario' => array('foreignKey' => 'cod_voluntario'),
							'Caso' => array('foreignKey' => 'cod_caso'));
		var $hasMany=array('Respuestaficha' => array('foreignKey' => 'num_evento', 'dependent' => true));
		
		
		var $validate=array(//'nom_comentario1'=> VALID_NOT_EMPTY,
							//'fec_proxrevision'=> '/[0-9]{4}[\-][0-9]{2}[\-][0-9]{2}$/i',
							'tip_proxrevision'=> VALID_NOT_EMPTY
							);
							
		var $jsFeedback=array(//'nom_comentario1'=> 'Ingrese Descripci�n',
							  //'fec_proxrevision'=> 'Ingrese fecha de la proxixma revision',
							  'tip_proxrevision'=> 'Ingrese tipo de la proxima revision'
							);
		
		
		function beforeSave() 
		{ 
		
			// Get month day and year from date string 
			
			if ($this->data['Seguimiento']['fec_proxrevision']==NULL){
				$month = 1;
				$day = 1;
				$year = 2100;
			}
			
			else {
				$timestamp = explode("-", $this->data['Seguimiento']['fec_proxrevision']);
				$month = $timestamp[1];
				$day = $timestamp[0];
				$year = $timestamp[2];
			}
			
			
			   
			$this->data['Seguimiento']['fec_proxrevision'] = date('Y-m-d', mktime(null, 
																	 		null, 
																			null, 
																			$month, 
																			$day, 
																			$year)); 
			return true; 
		}
		
		//Pasa Time Stamp a Fecha
		function toFecha($fecha)
		{
			if($fecha){
				$fec1=explode(" ", $fecha);
				$fec2=explode("-", $fec1[0]);
				return $fec2[0]."-".$fec2[1]."-".$fec2[2];
			}
			else return "";
		}
	}
?>
