<?php
class Comentario extends AppModel {

	var $name = 'Comentario';
	var $primaryKey = 'cod_comentario';

	var $belongsTo = array(
			'Persona' =>
				array('className' => 'Persona',
						'foreignKey' => 'cod_persona',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'counterCache' => ''
				),

	);
}
?>