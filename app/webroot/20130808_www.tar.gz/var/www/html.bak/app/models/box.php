<?php
class Box extends AppModel {

	var $name = 'Box';
	var $primaryKey = 'cod_box';

	var $hasMany = array('Turno' => array('foreignKey' => 'cod_box'));

}
?>