<?php
	
	class Permisoperfil extends AppModel
	{
		var $name='Permisoperfil'; // nombre del modelo
		var $useTable='permisoperfiles';
		var $primaryKey='cod_permisoperfil'; //cod_permiso
		var $belongsTo=array('Perfil' => array('foreignKey' => 'cod_perfil'),
							'Permiso' => array('foreignKey' => 'cod_permiso'));
		
		
	}
?>
