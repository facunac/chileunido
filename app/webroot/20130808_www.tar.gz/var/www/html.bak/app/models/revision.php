<?php
	
	class Revision extends AppModel
	{
		var $name='Revision '; // nombre del modelo
		var $useTable='revisiones';
	}

?>