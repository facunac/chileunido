<?php
class Role extends AppModel {

	var $name = 'Role';
	var $primaryKey = 'cod_rol';

}
?>