<?php
	
	class ControlDeCaso extends AppModel
	{
		var $name='ControlDeCaso'; // nombre del modelo
		var $useTable='casos';
	}

?>