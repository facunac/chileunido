 function OnSubmitForm()
{
  if(document.pressed == 'Ingresar')
  {
   document.formulario.action ="ingresar_nuevo.thtml";
  }
  else
  if(document.pressed == 'Derivar a Fundacion')
  {
    document.formulario.action ="ingresar_nuevo_derivado.thtml";
  }
  return true;
}