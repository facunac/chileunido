<?php
	class PagesController extends AppController
	{
		var $uses = null;
		var $layout = 'inicio';

		
		//se pone la funcion en blanco para sobreescribir la de app_controller
		//NO BORRAR
		function beforeFilter()
		{
		}
		
		function index()
		{

		}
		
		function display() 
		{
		}
	
	}
?>

