<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class OpcionesController extends AppController{
    var $name = "Opciones";
    var $helpers = array('Html', 'Form');




    

}
?>
