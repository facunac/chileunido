<?php

require_once(TESTS.'/app/cases/models/Seguimiento.test.php');
require_once(TESTS.'/app/cases/controllers/Indicadores.test.php');

class IndicadoresTest extends GroupTest {

        function IndicadoresTest() {

            $this->addTestCase(new SeguimientoTest());
            $this->addTestCase(new IndicadoresControllerTest());
            
            
           
        }
    }


?>
