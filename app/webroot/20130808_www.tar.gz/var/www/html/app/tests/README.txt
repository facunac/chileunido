--------------------------------------------------------------------------------
Cake Unit Test Suite
--------------------------------------------------------------------------------
$Id: README.txt 5 2006-05-28 10:33:04Z phpnut $
$Date: 2006-05-28 05:33:04 -0500 (Sun, 28 May 2006) $
$LastChangedBy: phpnut $
--------------------------------------------------------------------------------

RUNNING THE TESTS

All test cases should have the file suffix '.test.php'.
  Example:  controller.test.php

All group tests should have the file suffix '.group.php'.
  Example:  controller.group.php

This test suite is already in the proper directory structure for you to upload to your application.